package br.ocarina.mic

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.max
import kotlin.math.sqrt

class AudioEngine(private val cb: Callback) {
    interface Callback {
        fun onFrame(rms: Float, hz: Float, nota: OcaNote?)
        fun onNotaLigada(n: OcaNote)
        fun onNotaDesligada(n: OcaNote)
    }
    companion object { const val SR = 44100; const val HOP = 512 }

    private val yin = Yin(SR)
    private val frame = FloatArray(yin.frameSize)
    @Volatile private var rodando = false
    @Volatile private var calHops = 0
    private var calSoma = 0f; private var calN = 0
    private var th: Thread? = null

    /** Mede o ruído ambiente por ~1,5 s (peça silêncio ao usuário). */
    fun calibrarRuido() { calSoma = 0f; calN = 0; calHops = 130 }

    fun start() {
        if (rodando) return
        rodando = true
        th = Thread({ loop() }, "oca-audio").apply { priority = Thread.MAX_PRIORITY; start() }
    }
    fun stop() { rodando = false; th?.join(500) }

    private fun loop() {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SR, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, HOP * 8))
        } catch (e: SecurityException) { rodando = false; return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rodando = false; return }
        val s = ShortArray(HOP)
        var px = 0f; var py = 0f
        var atual: OcaNote? = null; var pend: OcaNote? = null; var pc = 0; var falta = 0
        rec.startRecording()
        while (rodando) {
            val n = rec.read(s, 0, HOP)
            if (n <= 0) continue
            System.arraycopy(frame, n, frame, 0, frame.size - n)
            var soma = 0f
            for (i in 0 until n) {  // passa-altas ~210 Hz: corta graves e ruído de manuseio
                val x = s[i] / 32768f
                val y = 0.97f * (py + x - px); px = x; py = y
                frame[frame.size - n + i] = y; soma += y * y
            }
            val rms = sqrt(soma / n)
            if (calHops > 0) {
                calSoma += rms; calN++; calHops--
                if (calHops == 0) Prefs.ruido = max(calSoma / calN, 0.0015f)
            }
            val mult = 8f - 6.5f * Prefs.sensibilidade / 100f
            val gate = max(Prefs.ruido * mult, 0.004f)
            val hz = if (rms > gate && calHops == 0) yin.detect(frame) else -1f
            val nota = OcaNote.achar(hz, Prefs.oitava, Prefs.tolerancia.toFloat())
            cb.onFrame(rms, hz, nota)
            if (nota == null) {
                pend = null; falta++
                if (falta >= 3 && atual != null) { cb.onNotaDesligada(atual); atual = null }
            } else if (nota == atual) { falta = 0; pend = null; pc = 0 }
            else {
                falta = 0
                if (nota == pend) pc++ else { pend = nota; pc = 1 }
                if (pc >= 2) {  // 2 quadros iguais (~23 ms) confirmam a nota
                    atual?.let { cb.onNotaDesligada(it) }
                    atual = nota; pend = null; pc = 0; cb.onNotaLigada(nota)
                }
            }
        }
        atual?.let { cb.onNotaDesligada(it) }
        rec.stop(); rec.release()
    }
}
