"""Porta fiel do Yin.kt + AudioEngine.kt (mesmos parâmetros) para validar o algoritmo fora do Android.
Sinais sintéticos: assobio, voz com harmônicos+vibrato, flauta, ruído. NÃO é teste com microfone real."""
import numpy as np, math
SR, HOP, W = 44100, 512, 1024
TMIN, TMAX = int(SR/720), int(SR/230)
FRAME = W + TMAX + 1
def yin(x, thr=0.15):
    d = np.zeros(TMAX+2)
    for t in range(1, TMAX+2): d[t] = np.sum((x[:W]-x[t:t+W])**2)
    run = 0.0; d[0] = 1
    for t in range(1, TMAX+2):
        run += d[t]; d[t] = 1 if run == 0 else d[t]*t/run
    t = TMIN; tau = -1
    while t <= TMAX:
        if d[t] < thr:
            while t+1 <= TMAX and d[t+1] < d[t]: t += 1
            tau = t; break
        t += 1
    if tau < 0: return -1
    a, b, c = d[tau-1], d[tau], d[tau+1]; den = a-2*b+c
    return SR/(tau + (0 if den == 0 else .5*(a-c)/den))
NOTAS = [("A",293.66),("C↓",349.23),("C→",440.0),("C←",493.88),("C↑",587.33)]
def achar(hz, tol=60):
    if hz <= 0: return None
    n = min(NOTAS, key=lambda n: abs(1200*math.log2(hz/n[1])))
    return n[0] if abs(1200*math.log2(hz/n[1])) <= tol else None
def hp(x):
    y = np.zeros_like(x); px = py = 0
    for i, v in enumerate(x): py = .97*(py+v-px); px = v; y[i] = py
    return y
rng = np.random.default_rng(1)
def sinal(f, tipo, dur=0.5):
    t = np.arange(int(SR*dur))/SR
    if tipo == "assobio": x = .3*np.sin(2*np.pi*f*t)
    elif tipo == "voz":
        fi = f*(1+.01*np.sin(2*np.pi*5*t)); ph = 2*np.pi*np.cumsum(fi)/SR
        x = .2*(np.sin(ph)+.6*np.sin(2*ph)+.4*np.sin(3*ph)+.25*np.sin(4*ph))
    else: x = .25*(np.sin(2*np.pi*f*t)+.15*np.sin(4*np.pi*f*t)+.05*np.sin(6*np.pi*f*t))
    return x
def ruido(x, snr_db):
    p = np.mean(x**2); n = rng.standard_normal(len(x)); n *= math.sqrt(p/10**(snr_db/10))/n.std(); return x+n
def estima(x):
    x = hp(x); r = []
    for s in range(0, len(x)-FRAME, HOP*2): r.append(yin(x[s:s+FRAME]))
    r = [v for v in r if v > 0]; return float(np.median(r)) if r else -1
print(f"{'tipo':8}{'SNR':>6}{'nota':>6}{'Hz':>9}{'erro(cents)':>13}  reconhecida")
tot = ok = 0
for tipo in ["assobio","voz","flauta"]:
    for snr in [99, 20, 10]:
        for nome, f in NOTAS:
            x = sinal(f, tipo); x = x if snr == 99 else ruido(x, snr)
            hz = estima(x); c = 1200*math.log2(hz/f) if hz > 0 else float("nan")
            r = achar(hz); tot += 1; ok += (r == nome)
            print(f"{tipo:8}{snr:>6}{nome:>6}{hz:9.2f}{c:13.1f}  {r} {'OK' if r==nome else 'FALHA'}")
print(f"\nTotal: {ok}/{tot} corretas")
# sequência: Canção de Ninar de Zelda (C←, C↑, C→, C←, C↑, C→) com pausas e ruído 15 dB, via máquina de estados
seq = [NOTAS[3],NOTAS[4],NOTAS[2],NOTAS[3],NOTAS[4],NOTAS[2]]
sig = np.concatenate([np.concatenate([ruido(sinal(f,"assobio",.35),15), rng.standard_normal(int(SR*.12))*.003]) for _,f in seq])
x = hp(sig); atual = None; pend = None; pc = falta = 0; lig = []
buf = np.zeros(FRAME)
for s in range(0, len(x)-HOP, HOP):
    buf = np.concatenate([buf[HOP:], x[s:s+HOP]]); rms = math.sqrt(np.mean(x[s:s+HOP]**2))
    n = achar(yin(buf)) if rms > 0.02 else None
    if n is None:
        pend = None; falta += 1
        if falta >= 3: atual = None
    elif n == atual: falta = 0; pend = None; pc = 0
    else:
        falta = 0; pc = pc+1 if n == pend else 1; pend = n
        if pc >= 2: atual = n; pend = None; pc = 0; lig.append((s/SR*1000, n))
print("Notas ligadas:", [n for _,n in lig], "(esperado: C← C↑ C→ C← C↑ C→)")
print("Latência de confirmação ≈ %.0f ms de áudio (2 quadros de hop) + janela YIN" % (2*HOP/SR*1000))
