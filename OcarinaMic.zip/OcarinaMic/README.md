# Ocarina of Time · Microfone Real (Android)

Toque as 5 notas da Ocarina com assobio, voz ou instrumento. O app detecta a nota (YIN) e toca no botão
virtual correspondente (A, C↓, C→, C←, C↑) do emulador via Serviço de Acessibilidade. Sem root, sem PC, sem modificar a ROM.

| Nota | Hz | Botão |
|---|---|---|
| Ré | 293,66 | A |
| Fá | 349,23 | C↓ |
| Lá | 440,00 | C→ |
| Si | 493,88 | C← |
| Ré agudo | 587,33 | C↑ |

## Compilar (precisa de Android Studio uma vez)
1. Abra a pasta no Android Studio (Koala+). Ele baixa o Gradle e cria o wrapper.
2. Build > Build APK(s). APK em `app/build/outputs/apk/debug/`. Instale no celular (permita "fontes desconhecidas").
   Alternativa sem PC: suba o projeto no GitHub e compile com GitHub Actions (`gradle assembleDebug`).

## Usar
1. Abra o app > **Iniciar microfone** (aceite a permissão).
2. **Calibrar ruído**: silêncio por 1,5 s.
3. Teste: com o interruptor "Enviar toques" DESLIGADO, assobie e veja nota/música no visor.
   Se sua voz for grave/aguda demais, mude a **oitava**.
4. **1) Ativar acessibilidade** > Ocarina Microfone > ligar.
5. **2) Calibrar botões**: abre o emulador; toque, quando pedido, em A, C↓, C→, C←, C↑ do controle virtual na tela.
6. Ligue "Enviar toques ao emulador". No jogo, equipe a Ocarina num botão C, abra-a e assobie.

## Emuladores (M64Plus FZ / RetroArch)
- Use controles virtuais na tela, em posição fixa (não mova o layout depois de calibrar).
- RetroArch: núcleo Mupen64Plus-Next/ParaLLEl, overlay de gamepad ativo.
- M64Plus FZ: touchscreen ligado em Configurações > Entrada.
- Nenhum dos dois expõe API para injetar botões, então a integração é por acessibilidade (igual para ambos).

## Limitações (honestas)
- **Não testado em celular real nem em emulador real.** O APK não foi compilado neste ambiente (sem Android SDK).
- Validação feita: porta Python do YIN/máquina de estados com sinais sintéticos (`tools/test_yin.py`, `tools/resultado_teste.txt`).
- Latência real = áudio (~23 ms) + YIN + atraso do `dispatchGesture` (depende do aparelho; pode ser 30–100 ms).
- Um toque por vez: a Ocarina só toca uma nota por vez, então basta. Trocar de nota rápido pode perder um toque.
- Apps de jogo podem bloquear acessibilidade em telas protegidas; emuladores comuns não bloqueiam.
- Android pode silenciar o microfone de apps em segundo plano; por isso o app usa serviço em primeiro plano (notificação).
- As melodias foram escritas de memória; confira no jogo (editar `Musicas` em `Ocarina.kt`). O jogo reconhece as músicas sozinho; o app só usa a lista para exibir.
- Nenhuma ROM foi recebida nesta conversa; como a solução é externa, a ROM não precisa de alteração.

## Compilar na nuvem (sem PC)
1. Crie um repositório no GitHub e envie TODO o conteúdo desta pasta (inclusive `.github/workflows/build.yml`).
2. Aba **Actions** > "Compilar APK" > rode. Ao terminar, baixe o artefato **OcarinaMic-apk**, descompacte e instale o `.apk`.
3. Se der erro, copie o log vermelho e me mande.
